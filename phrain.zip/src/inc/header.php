<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://firebasestorage.googleapis.com/v0/b/johnjadd-3524a.appspot.com/o/cdn%2Fjs%2Ffirebase.uploads.js?alt=media&token=98a740c9-ec55-4b62-b656-bdf8ba46b7de"></script>
<script src="https://www.gstatic.com/firebasejs/5.4.2/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.4.2/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.4.2/firebase-database.js"></script>
<script>
var config = {
  apiKey: "AIzaSyA0fkeZmoVeTDLnrAYpZaOvcrQmIUT4dEI",
  authDomain: "johnjadd-3524a.firebaseapp.com",
  databaseURL: "https://johnjadd-3524a.firebaseio.com",
  projectId: "johnjadd-3524a",
  storageBucket: "johnjadd-3524a.appspot.com",
  messagingSenderId: "1091789743614"
};
firebase.initializeApp(config);
</script>